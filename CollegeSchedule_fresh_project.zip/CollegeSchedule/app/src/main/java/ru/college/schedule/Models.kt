package ru.college.schedule

data class Lesson(val number: String, val time: String, val subject: String, val teacher: String)
data class DaySchedule(val date: String, val weekday: String, val lessons: List<Lesson>)
