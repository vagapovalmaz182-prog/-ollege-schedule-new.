package ru.college.schedule

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import kotlin.concurrent.thread

class ScheduleWidget : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
        if (intent.action == "ru.college.schedule.PREV") prefs.edit().putInt("offset", (prefs.getInt("offset", 0) - 1).coerceAtLeast(0)).apply()
        if (intent.action == "ru.college.schedule.NEXT") prefs.edit().putInt("offset", prefs.getInt("offset", 0) + 1).apply()
        super.onReceive(context, intent)
        refresh(context)
    }
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = refresh(context)
    companion object {
        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ScheduleWidget::class.java))
            if (ids.isEmpty()) return
            thread {
                val loaded = runCatching { ScheduleRepository.load() }
                ids.forEach { id ->
                    val p = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
                    val today = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale("ru")).format(java.util.Date())
                    val list = loaded.getOrNull().orEmpty()
                    val base = list.indexOfFirst { it.date == today }.let { if (it < 0) 0 else it }
                    val index = (base + p.getInt("offset", 0)).coerceIn(0, (list.size - 1).coerceAtLeast(0))
                    val day = list.getOrNull(index)
                    val views = RemoteViews(context.packageName, R.layout.widget_schedule)
                    views.setTextViewText(R.id.day, day?.let { "${it.weekday}, ${it.date}" } ?: "Расписание 1С-2")
                    val text = when { loaded.isFailure -> "Не удалось загрузить расписание. Проверь интернет и открой приложение."; day == null -> "Нет опубликованных занятий."; day.lessons.isEmpty() -> "Пар нет."; else -> day.lessons.sortedBy { it.number.toIntOrNull() ?: 99 }.joinToString("\n\n") { "${it.number} ПАРА  •  ${it.time}\n${it.subject}" + if (it.teacher.isNotBlank()) "\n${it.teacher}" else "" } }
                    views.setTextViewText(R.id.lessons, text)
                    views.setTextViewText(R.id.status, "УТЭК  •  1С-2")
                    views.setOnClickPendingIntent(R.id.prev, pending(context, "ru.college.schedule.PREV", id * 2))
                    views.setOnClickPendingIntent(R.id.next, pending(context, "ru.college.schedule.NEXT", id * 2 + 1))
                    val bgAlpha = p.getInt("bgAlpha", 94).coerceIn(10, 100) / 100f
                    val cellAlpha = p.getInt("cellAlpha", 100).coerceIn(10, 100) / 100f
                    views.setFloat(R.id.widgetRoot, "setAlpha", bgAlpha)
                    views.setFloat(R.id.lessons, "setAlpha", cellAlpha)
                    manager.updateAppWidget(id, views)
                }
            }
        }
        private fun pending(c: Context, action: String, request: Int) = PendingIntent.getBroadcast(c, request, Intent(c, ScheduleWidget::class.java).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
