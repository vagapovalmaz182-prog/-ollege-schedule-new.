package ru.college.schedule

import org.jsoup.Jsoup
import java.net.URL

object ScheduleRepository {
    private const val INDEX = "https://uecoll.ru/wp-content/uploads/energy/10_1.html"
    private const val GROUP = "1 С-2"
    fun load(): List<DaySchedule> {
        val index = Jsoup.connect(INDEX).userAgent("Mozilla/5.0 CollegeSchedule").timeout(20000).get()
        val link = index.select("a[href]").firstOrNull { it.text().replace('\u00a0',' ').contains("13.02.12") }
            ?: error("Не найдена страница специальности 13.02.12")
        val page = Jsoup.connect(URL(URL(INDEX), link.attr("href")).toString()).userAgent("Mozilla/5.0").timeout(20000).get()
        val rows = page.select("tr")
        var groupCol = -1
        var weekday = ""
        var date = ""
        var lessons = mutableListOf<Lesson>()
        val result = mutableListOf<DaySchedule>()
        for (row in rows) {
            val cells = row.select("th,td")
            if (cells.isEmpty()) continue
            val texts = cells.map { it.text().replace('\u00a0',' ').trim() }
            val header = texts.indexOfFirst { it.contains(GROUP, true) }
            if (header >= 0 && texts.any { it.contains("День/Пара", true) }) { groupCol = header; continue }
            val whole = row.text().replace('\u00a0',' ').replace(Regex("\\s+"), " ")
            val dm = Regex("(ПОНЕДЕЛЬНИК|ВТОРНИК|СРЕДА|ЧЕТВЕРГ|ПЯТНИЦА|СУББОТА|ВОСКРЕСЕНЬЕ).*?(\\d{2}\\.\\d{2}\\.\\d{4})", RegexOption.IGNORE_CASE).find(whole)
            if (dm != null) {
                if (weekday.isNotEmpty()) result += DaySchedule(date, weekday, lessons.toList())
                weekday = dm.groupValues[1].lowercase().replaceFirstChar { it.uppercase() }
                date = dm.groupValues[2]
                lessons = mutableListOf()
                continue
            }
            if (groupCol < 0 || weekday.isEmpty() || cells.size <= groupCol) continue
            val lm = Regex("^(\\d+)\\.?\\s+(\\d{1,2}[.:]\\d{2})\\s*[-–—]\\s*(\\d{1,2}[.:]\\d{2})").find(texts.firstOrNull().orEmpty()) ?: continue
            val number = lm.groupValues[1] // Deliberately accepts 0 (нулевая пара).
            val time = "${lm.groupValues[2]}–${lm.groupValues[3]}"
            val raw = cells[groupCol].text().replace('\u00a0',' ').trim()
            if (raw.isBlank() || raw == "—" || raw == "-") continue
            val parts = raw.split(Regex("\\s+-\\s+"), limit = 2)
            lessons += Lesson(number, time, parts[0].trim(), parts.getOrNull(1).orEmpty().trim())
        }
        if (weekday.isNotEmpty()) result += DaySchedule(date, weekday, lessons.toList())
        if (result.isEmpty()) error("Не удалось распознать расписание. Возможно, сайт изменил таблицу.")
        return result
    }
}
