package ru.college.schedule

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 9, 15)
    private val purple = Color.rgb(182, 156, 255)
    private var days: List<DaySchedule> = emptyList()
    private var selected = 0
    private lateinit var content: LinearLayout
    private lateinit var header: TextView
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showShell(); load() }
    private fun showShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 28, 20, 18); setBackgroundColor(bg) }
        val title = TextView(this).apply { text = "РАСПИСАНИЕ"; textSize = 12f; letterSpacing = .18f; setTextColor(purple) }
        root.addView(title)
        root.addView(TextView(this).apply { text = "1С-2"; textSize = 32f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); setPadding(0, 5, 0, 2) })
        root.addView(TextView(this).apply { text = "13.02.12  •  УТЭК"; textSize = 13f; setTextColor(0xFF9995A8.toInt()) })
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, 22, 0, 14) }
        val prev = button("‹") { if (days.isNotEmpty()) { selected = (selected - 1).coerceAtLeast(0); render() } }
        header = TextView(this).apply { text = "Загрузка расписания…"; gravity = Gravity.CENTER; textSize = 15f; setTextColor(Color.WHITE) }
        val next = button("›") { if (days.isNotEmpty()) { selected = (selected + 1).coerceAtMost(days.lastIndex); render() } }
        nav.addView(prev, LinearLayout.LayoutParams(48, 44)); nav.addView(header, LinearLayout.LayoutParams(0, 44, 1f)); nav.addView(next, LinearLayout.LayoutParams(48, 44)); root.addView(nav)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this); scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        status = TextView(this).apply { textSize = 12f; setTextColor(0xFF858192.toInt()); setPadding(2, 12, 2, 4) }; root.addView(status)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 12, 0, 0) }
        tabs.addView(button("Расписание") { render() }, LinearLayout.LayoutParams(0, 46, 1f))
        tabs.addView(button("Настройки") { showSettings() }, LinearLayout.LayoutParams(0, 46, 1f))
        root.addView(tabs); setContentView(root)
    }
    private fun button(label: String, action: () -> Unit) = TextView(this).apply { text = label; gravity = Gravity.CENTER; textSize = 15f; setTextColor(Color.WHITE); background = rounded(0xFF211B30.toInt(), 18); setOnClickListener { action() } }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun load() { status.text = "Загружаем данные с сайта колледжа…"; thread { val result = runCatching { ScheduleRepository.load() }; runOnUiThread { if (result.isSuccess) { days = result.getOrThrow(); val today = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale("ru")).format(java.util.Date()); selected = days.indexOfFirst { it.date == today }.takeIf { it >= 0 } ?: 0; render() } else status.text = "Ошибка: ${result.exceptionOrNull()?.message}" } } }
    private fun render() {
        body.removeAllViews(); val day = days.getOrNull(selected); header.text = day?.let { "${it.weekday}, ${it.date}" } ?: "Расписание"
        if (day == null || day.lessons.isEmpty()) { body.addView(TextView(this).apply { text = "На этот день пар нет"; setTextColor(Color.WHITE); textSize = 16f; setPadding(8, 30, 8, 30) }); return }
        day.lessons.sortedBy { it.number.toIntOrNull() ?: 99 }.forEach { lesson ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); background = rounded(0xFF201A2D.toInt(), 20) }
            val line = TextView(this).apply { text = "${lesson.number} ПАРА     ${lesson.time}"; textSize = 12f; setTextColor(purple); letterSpacing = .04f }
            val subject = TextView(this).apply { text = lesson.subject; textSize = 17f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); setPadding(0, 8, 0, 4) }
            card.addView(line); card.addView(subject)
            if (lesson.teacher.isNotBlank()) card.addView(TextView(this).apply { text = lesson.teacher; textSize = 13f; setTextColor(0xFFB8B3C4.toInt()) })
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 10; body.addView(card, lp)
        }
        status.text = "Источник: uecoll.ru  •  Группа 1С-2"
    }
    private fun showSettings() { body.removeAllViews(); header.text = "Настройки"; val info = TextView(this).apply { text = "Группа: 1С-2\nСпециальность: 13.02.12\n\nВиджет можно добавить на главный экран через меню виджетов Android.\n\nОбновление расписания выполняется с сайта колледжа."; textSize = 16f; setTextColor(Color.WHITE); setPadding(16, 20, 16, 20); background = rounded(0xFF201A2D.toInt(), 20) }; body.addView(info); body.addView(button("Обновить расписание") { load() }, LinearLayout.LayoutParams(-1, 48).apply { topMargin = 12 }) }
}
