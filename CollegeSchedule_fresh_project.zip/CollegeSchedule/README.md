# College Schedule

Android timetable app for group 1С-2 (specialty 13.02.12).

Build with Gradle 8.9 and JDK 17:

    gradle assembleDebug

APK: `app/build/outputs/apk/debug/app-debug.apk`.

The timetable is loaded from the college's public schedule page. The parser accepts lesson number `0` and time ranges using either `.` or `:`. The public page's exact table structure can change; if that happens, the app reports a parsing error instead of claiming the timetable is current.
